# IMPROVEMENTS.md — Centralized Idea List
_Last updated (AEST): 2025-08-11 07:44:47 +1000_

Status legend: ✅ Implemented · 🟡 Pending · ⏳ Deferred · ❌ Rejected

## Build QoS
- 🟡 Pin Node and Windows runner across all build workflows (20.19.4, windows-2022).
- 🟡 Add smoke checks before artifact upload.
- 🟡 Artifact naming normalization (`CommentHQ-BundleMe-GUI-<ver>-portable.exe`).

## Repo Sync
- ✅ SYNC-first pre-step before any repo action.
- 🟡 Add repo SNAP workflow that writes a short JSON snapshot artifact (public data only).

## UI Enhancements
- ✅ Visibility panel badges with AEST timestamps (safe mode: status-only when IPC missing).
- ⏳ IPC module for in-GUI visibility toggles + auto-reprivate.

## CI/CD Optimizations
- 🟡 Cache npm with `cache-dependency-path` on GUI lockfile.
- 🟡 Compress artifacts and attach SHA256 JSON alongside EXE.

## Policy & Bookkeeping
- ✅ POLICY.md baseline established.
- ✅ VERSIONS entry format standardized.
- ✅ Centralized improvements list (this file).
