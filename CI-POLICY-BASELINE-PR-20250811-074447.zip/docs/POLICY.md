# POLICY.md — Master Policy & Bookkeeping Protocol
Framework: CommentHQ / Framework-Kit-FULL-COMPLIANT
Version: 2025-08-11-AEST-BASELINE
Generated: 2025-08-11 07:44:47 +1000

## 1) SYNC Pre-Step — Mandatory Before All Repo Tasks
Trigger phrase: **Scan and collect latest repo state**

Actions:
1. Snapshot public repo state: visibility, default branch & HEAD, open PRs, last 10 Actions runs, Releases, presence of canonical workflows.
2. Anchor timestamps in **AEST**.
3. Reference the fresh SNAP in responses before proposing changes.

Scope: applies to any repo-related task (workflow edits, kit deployments, PRs, releases).

## 2) Control Surface Policy
- Use **GitHub UI/Actions** and the **CommentHQ Portable GUI** only.
- No local CLI unless explicitly requested.
- Builds: GitHub Actions on Windows (**windows-2022**), Node **20.19.4** (pinned).

## 3) Build QoS Rules
- Pinned OS/toolchain; deterministic installs (`npm ci`, create lockfile if missing).
- Smoke checks prior to artifact/release.
- Cache dependencies without sacrificing determinism.
- Windows portable `.exe` artifacts required.

## 4) Workflow Management
- Legacy workflows go to `.github/workflows/legacy/` (disables auto-runs).
- Prefer `workflow_dispatch` for manual/experimental jobs.
- YAML must be parser-safe (spaces, plain quotes, no BOM).

## 5) Import/Export Compliance
- 1:1 source→destination verification: UTF-8 char count + SHA-256 per file.
- Halt on mismatch/missing until resolved (no silent healing).
- Preserve structure: `docs/`, `.github/workflows/`, `tools/`.
- CLOUD kits include cloud import execution prompt.

## 6) Policy Versioning
- All policy changes logged in `docs/VERSIONS.md` with AEST timestamp, summary, rationale.

## 7) Incremental Backup (Future)
- Optional background incremental snapshots around major changes, linked from `VERSIONS.md`.

## 8) Dummy Failures / Legacy Noise Prevention
- Example: Commit `74b782e`, `.github/workflows/build-orchestrator.yml` auto-run fail.
- Fix: archive to `/legacy/` or convert to manual-only stub.

## 9) Approval Gate
- For major workflow/architecture changes, present a short proposal and require explicit user approval.
