# SYNC.md — Operational Reminder

**SYNC first:** Scan and collect latest repo state (visibility, default branch + HEAD, open PRs, last 10 Actions runs, Releases, canonical workflows). Anchor timestamps in AEST. Reference the SNAP before proposing changes.
