<!-- Paste the following block at the TOP of docs/VERSIONS.md -->

## Policy Baseline v1.0 (AEST)
- Timestamp: 2025-08-11 07:44:47 +1000
- POLICY.md SHA-256: PLACEHOLDER_SHA256
- Summary: Introduce POLICY.md + SYNC.md; add IMPROVEMENTS.md; silence legacy workflow noise; keep builds UI-only/manual unless approved.
- Rationale: Eliminate drift, stabilize CI, centralize policy & improvements.

<!-- End paste block -->
