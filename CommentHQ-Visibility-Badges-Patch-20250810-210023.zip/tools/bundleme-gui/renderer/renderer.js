console.log('BundleMe GUI loaded');

(function(){
  const $ = (s)=>document.querySelector(s);
  const log = (m)=>{ const el=$("#vis-log"); if(!el) return; el.textContent += (m+"\n"); el.scrollTop=el.scrollHeight; };
  const slugEl=$("#repo-slug"), tokEl=$("#gh-token");

  $("#save-token")?.addEventListener("click", async ()=>{
    const t = tokEl.value.trim(); if(!t){ log("Enter a token first"); return; }
    await window.repo.saveToken(t); log("Token saved to OS keychain");
  });

  $("#clear-token")?.addEventListener("click", async ()=>{
    await window.repo.clearToken(); log("Token cleared");
  });

  const parse = ()=>{
    const v=slugEl?.value?.trim()||"Falcordog/youtube-comment-hq";
    const [o,r]=v.split("/");
    return {owner:o,repo:r};
  };

  $("#btn-status")?.addEventListener("click", async ()=>{
    try{ const {owner,repo}=parse(); const j=await window.repo.get(owner,repo); log("Status: "+(j.visibility || (j.private ? "private" : "public"))); }
    catch(e){ log("ERR "+e); }
  });

  $("#btn-public")?.addEventListener("click", async ()=>{
    try{
      const {owner,repo}=parse();
      await window.repo.setVisibility(owner,repo,false); log("Repo is PUBLIC");
      await window.repo.scheduleReprivate(owner,repo,15); log("Auto re-private scheduled in 15 min");
    } catch(e){ log("ERR "+e); }
  });

  $("#btn-private")?.addEventListener("click", async ()=>{
    try{ const {owner,repo}=parse(); await window.repo.setVisibility(owner,repo,true); log("Repo is PRIVATE"); }
    catch(e){ log("ERR "+e); }
  });
})();

// === Status badges + AEST timestamp ===
(function(){
  const $ = (s)=>document.querySelector(s);
  const formatAEST = (iso) => {
    try { return new Date(iso).toLocaleString('en-AU', { timeZone: 'Australia/Melbourne' }); }
    catch { return iso || '—'; }
  };
  const setTokenBadge = async () => {
    try {
      const has = await window.repo.hasToken();
      const b = $("#token-badge"); if (!b) return;
      b.textContent = has ? "Token ✓" : "Token ✗";
      b.classList.toggle("ok", !!has);
      b.classList.toggle("off", !has);
    } catch {}
  };
  const setVisBadge = (visibility) => {
    const b = $("#vis-badge"); if (!b) return;
    const v = (visibility||"").toLowerCase();
    if (v === "public") { b.textContent = "Public"; b.classList.add("ok"); b.classList.remove("off"); }
    else if (v === "private") { b.textContent = "Private"; b.classList.remove("ok"); b.classList.add("off"); }
    else { b.textContent = "Unknown"; b.classList.remove("ok","off"); }
  };
  const refresh = async () => {
    const asof = new Date().toLocaleString('en-AU', { timeZone: 'Australia/Melbourne' });
    if (document.getElementById("asof")) document.getElementById("asof").textContent = "As of: " + asof;
    await setTokenBadge();
    try {
      const repoField = document.getElementById("repo-slug");
      const v = (repoField?.value?.trim()) || "Falcordog/youtube-comment-hq";
      const [owner, repo] = v.split("/");
      const info = await window.repo.get(owner, repo);
      setVisBadge(info.visibility || (info.private ? "private" : "public"));
      if (document.getElementById("repo-updated")) document.getElementById("repo-updated").textContent = "Repo updated: " + formatAEST(info.updated_at);
    } catch (e) {
      setVisBadge("unknown");
    }
  };
  document.getElementById("btn-refresh")?.addEventListener("click", refresh);
  document.getElementById("btn-status")?.addEventListener("click", refresh);
  // initial render
  refresh();
})();